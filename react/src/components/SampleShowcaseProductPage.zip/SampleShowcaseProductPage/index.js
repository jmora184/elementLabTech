export { default } from './SampleShowcaseProductPage';
